c, link = emk.module("c", "link")

emk.subdir("test")
